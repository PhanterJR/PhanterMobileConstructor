# -*- coding: utf-8 -*-

def index():
    return dict()

def filter(d):
    import re
    if isinstance(d, dict):
        html_filtrado = re.compile(
            '\n\s\s+\n').sub('\n', response.render(d))
    else:
        html_filtrado = re.compile(
            '\n\s\s+\n').sub('\n', response.render(d()))

    return html_filtrado
response._caller = filter