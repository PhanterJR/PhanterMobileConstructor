# -*- coding: utf-8 -*-
from plugin_phantermobileconstructor.phanterandroid import PhanterAndroid
phanterandroid = PhanterAndroid('www')
